var $progressValue = 0;
var resultList = [];
var firebaseConfig = {
    apiKey: "AIzaSyB-W2AktdEtM7z_KHSWXXT_3PoBoWFdubM",
    authDomain: "dredu-71835.firebaseapp.com",
    databaseURL: "https://dredu-71835.firebaseio.com",
    projectId: "dredu-71835",
    storageBucket: "dredu-71835.appspot.com",
    messagingSenderId: "1010179971420",
    appId: "1:1010179971420:web:d2fc28ac5634b8ee8a0999",
    measurementId: "G-19Z5Q66FHX"
  };  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();
  var database = firebase.database();
var i = 0;
var quizdata = [{question : "Verify Human : 2+2 = " , options : ['1' , '2' ,'3' ,'4'] , answer: '4'}];
var fb_db = firebase.database().ref("users/EEWydIQ4cmhRP1eCZzMKBbHv7Qo1/question_paper/" );
//function getting(){
//};     
function getting(){
  fb_db.child('q2/').once('value').then(function(snapshot) {
    console.log("called 3");
    snapshot.forEach(function(childSnapshot) {
    var childKey = childSnapshot.key;
    var childData = childSnapshot.val();
    console.log(childData.user_name);
    const title = childData.user_name;
    const input1 = childData.option_1;
    const input2 = childData.option_2;
    const input3 = childData.option_3;
    const input4 = childData.option_4;
    const value = childData.correct;
    quizdata.push({ question: title , options: [input1,input2,input3,input4] , answer: value});
    console.log(quizdata[i].options);
    i+=1;
    console.log(i);
  }); 
}); 
 /* fb_db.child('q2/').once('value' , function(snapshot) {
    console.log("called 3");
    snapshot.forEach(function(childSnapshot) {
    var childKey = childSnapshot.key;
    var childData = childSnapshot.val();
    console.log(childData.user_name);
    const title = childData.user_name;
    const input1 = childData.option_1;
    const input2 = childData.option_2;
    const input3 = childData.option_3;
    const input4 = childData.option_4;
    const value = childData.correct;
    quizdata.push({ question: title , options: [input1,input2,input3,input4] , answer: value});
    console.log(quizdata[i].options);
    i+=1;
    console.log(i);
  }); 
}); */
};   
/** Random shuffle questions **/

function shuffleArray(question) {
  var shuffled = question.sort(function () {
    return .5 - Math.random();
  });
  console.log("called");
  return shuffled;
}

function shuffle(a) {
  for (var i = a.length; i; i--) {
    var j = Math.floor(Math.random() * i);
    var _ref = [a[j], a[i - 1]];
    a[i - 1] = _ref[0];
    a[j] = _ref[1];
  }
}

/*** Return shuffled question ***/
function generateQuestions() {
  console.log("called from generate question :");
  console.log(quizdata.length);
  var questions = shuffleArray(quizdata);
  return questions;
}

/*** Return list of options ***/
function returnOptionList(opts, i) {

  var optionHtml = '<li class="myoptions">' +
  '<input value="' + opts + '" name="optRdBtn" type="radio" id="rd_' + i + '">' +
  '<label for="rd_' + i + '">' + opts + '</label>' +
  '<div class="bullet">' +
  '<div class="line zero"></div>' +
  '<div class="line one"></div>' +
  '<div class="line two"></div>' +
  '<div class="line three"></div>' +
  '<div class="line four"></div>' +
  '<div class="line five"></div>' +
  '<div class="line six"></div>' +
  '<div class="line seven"></div>' +
  '</div>' +
  '</li>';

  return optionHtml;
}

/** Render Options **/
function renderOptions(optionList) {
  var ulContainer = $('<ul>').attr('id', 'optionList');
  for (var i = 0, len = optionList.length; i < len; i++) {
    var optionContainer = returnOptionList(optionList[i], i);
    ulContainer.append(optionContainer);
  }
  $(".answerOptions").html('').append(ulContainer);
}

/** Render question **/
function renderQuestion(question) {
  $(".question").html("<h1>" + question + "</h1>");
}

/** Render quiz :: Question and option **/
function renderQuiz(questions, index) {
  console.log("called render quiz");

  var currentQuest = questions[index];
  renderQuestion(currentQuest.question);
  renderOptions(currentQuest.options);
  console.log("Question");
  console.log(questions[index]);
}

/** Return correct answer of a question ***/
function getCorrectAnswer(questions, index) {
  return questions[index].answer;
}

/** pushanswers in array **/
function correctAnswerArray(resultByCat) {
  var arrayForChart = [];
  for (var i = 0; i < resultByCat.length; i++) {
    arrayForChart.push(resultByCat[i].correctanswer);
  }

  return arrayForChart;
}
/** Generate array for percentage calculation **/
function genResultArray(results, wrong) {
  var resultByCat = resultByCategory(results);
  var arrayForChart = correctAnswerArray(resultByCat);
  arrayForChart.push(wrong);
  return arrayForChart;
}

/** percentage Calculation **/
function percentCalculation(array, total) {
  var percent = array.map(function (d, i) {
    return (100 * d / total).toFixed(2);
  });
  return percent;
}

/*** Get percentage for chart **/
function getPercentage(resultByCat, wrong) {
  var totalNumber = resultList.length;
  var wrongAnwer = wrong;
  //var arrayForChart=genResultArray(resultByCat, wrong);
  //return percentCalculation(arrayForChart, totalNumber);
}

/** count right and wrong answer number **/
function countAnswers(results) {

  var countCorrect = 0,countWrong = 0;

  for (var i = 0; i < results.length; i++) {
    if (results[i].iscorrect == true)
    countCorrect++;else
    countWrong++;
  }

  return [countCorrect, countWrong];
}

/**** Categorize result *****/
function resultByCategory(results) {

  var categoryCount = [];
  var ctArray = results.reduce(function (res, value) {
    if (!res[value.category]) {
      res[value.category] = {
        category: value.category,
        correctanswer: 0 };

      categoryCount.push(res[value.category]);
    }
    var val = value.iscorrect == true ? 1 : 0;
    res[value.category].correctanswer += val;
    return res;
  }, {});

  categoryCount.sort(function (a, b) {
    return a.category - b.category;
  });

  return categoryCount;
}


/** Total score pie chart**/
function totalPieChart(_upto, _cir_progress_id, _correct, _incorrect) {

  $("#" + _cir_progress_id).find("._text_incor").html("Incorrect : " + _incorrect);
  $("#" + _cir_progress_id).find("._text_cor").html("Correct : " + _correct);

  var unchnagedPer = _upto;

  _upto = _upto > 100 ? 100 : _upto < 0 ? 0 : _upto;

  var _progress = 0;

  var _cir_progress = $("#" + _cir_progress_id).find("._cir_P_y");
  var _text_percentage = $("#" + _cir_progress_id).find("._cir_Per");

  var _input_percentage;
  var _percentage;

  var _sleep = setInterval(_animateCircle, 25);

  function _animateCircle() {
    //2*pi*r == 753.6 +xxx=764
    _input_percentage = _upto / 100 * 764;
    _percentage = _progress / 100 * 764;

    _text_percentage.html(_progress + '%');

    if (_percentage >= _input_percentage) {
      _text_percentage.html('<tspan x="50%" dy="0em">' + unchnagedPer + '% </tspan><tspan  x="50%" dy="1.9em">Your Score</tspan>');
      clearInterval(_sleep);
    } else {

      _progress++;

      _cir_progress.attr("stroke-dasharray", _percentage + ',764');
    }
  }
}

function renderBriefChart(correct, total, incorrect) {
  var percent = 100 * correct / total;
  if (Math.round(percent) !== percent) {
    percent = percent.toFixed(2);
  }

  totalPieChart(percent, '_cir_progress', correct, incorrect);

}
/*** render chart for result **/
function renderChart(data) {
  var ctx = document.getElementById("myChart");
  var myChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ["Verbal communication",
      "Non-verbal communication",
      "Written communication",
      "Incorrect"],

      datasets: [
      {

        data: data,
        backgroundColor: ['#e6ded4',
        '#968089',
        '#e3c3d4',
        '#ab4e6b'],

        borderColor: ['rgba(239, 239, 81, 1)',
        '#8e3407',
        'rgba((239, 239, 81, 1)',
        '#000000'],

        borderWidth: 1 }] },



    options: {
      pieceLabel: {
        render: 'percentage',
        fontColor: 'black',
        precision: 2 } } });




}

/** List question and your answer and correct answer  
  
  *****/
function getAllAnswer(results) {
  var innerhtml = "";
  for (var i = 0; i < results.length; i++) {

    var _class = results[i].iscorrect ? "item-correct" : "item-incorrect";
    var _classH = results[i].iscorrect ? "h-correct" : "h-incorrect";


    var _html = '<div class="_resultboard ' + _class + '">' +
    '<div class="_header">' + results[i].question + '</div>' +
    '<div class="_yourans ' + _classH + '">' + results[i].clicked + '</div>';

    var html = "";
    if (!results[i].iscorrect)
    html = '<div class="_correct">' + results[i].answer + '</div>';
    _html = _html + html + '</div>';
    innerhtml += _html;
  }

  $(".allAnswerBox").html('').append(innerhtml);
}
/** render  Brief Result **/
function renderResult(resultList) {

  var results = resultList;
  console.log(results);
  var countCorrect = countAnswers(results)[0],
  countWrong = countAnswers(results)[1];


  renderBriefChart(countCorrect, resultList.length, countWrong);
}

function renderChartResult() {
  var results = resultList;
  var countCorrect = countAnswers(results)[0],
  countWrong = countAnswers(results)[1];
  var dataForChart = genResultArray(resultList, countWrong);
  renderChart(dataForChart);
}

/** Insert progress bar in html **/
function getProgressindicator(length) {
  var progressbarhtml = " ";
  for (var i = 0; i < length; i++) {
    progressbarhtml += '<div class="my-progress-indicator progress_' + (i + 1) + ' ' + (i == 0 ? "active" : "") + '"></div>';
  }
  $(progressbarhtml).insertAfter(".my-progress-bar");
}

/*** change progress bar when next button is clicked ***/
function changeProgressValue() {
  $progressValue += 9;
  if ($progressValue >= 100) {

  } else {
    if ($progressValue == 99) $progressValue = 100;
    $('.my-progress').
    find('.my-progress-indicator.active').
    next('.my-progress-indicator').
    addClass('active');
    $('progress').val($progressValue);
  }
  $('.js-my-progress-completion').html($('progress').val() + '% complete');

}
function addClickedAnswerToResult(questions, presentIndex, clicked) {
  var correct = getCorrectAnswer(questions, presentIndex);
  var result = {
    index: presentIndex,
    question: questions[presentIndex].question,
    clicked: clicked,
    iscorrect: clicked == correct ? true : false,
    answer: correct,
    category: questions[presentIndex].category };

  resultList.push(result);

  console.log("result");
  console.log(result);

  }
function loadTest(){
  console.log("called 2");
  getting();
  var presentIndex = 0;
  var clicked = 0;
  console.log("called 1 ");
  var questions = generateQuestions();
  console.log(questions);
  console.log(questions.length);
  renderQuiz(questions, presentIndex);
  getProgressindicator(questions.length);

  $(".answerOptions ").on('click', '.myoptions>input', function (e) {
    clicked = $(this).val();

    if (questions.length == presentIndex + 1) {
      $("#submit").removeClass('hidden');
      $("#next").addClass("hidden");
    } else
    {

      $("#next").removeClass("hidden");
    }



  });



  $("#next").on('click', function (e) {
    e.preventDefault();
    if ( presentIndex != 0 ){
      addClickedAnswerToResult(questions, presentIndex, clicked);
    }
    

    $(this).addClass("hidden");

    presentIndex++;
    console.log(questions.length);
    renderQuiz(questions, presentIndex);
    changeProgressValue();
  });

  $("#submit").on('click', function (e) {
    addClickedAnswerToResult(questions, presentIndex, clicked);
    $('.multipleChoiceQues').hide();
    $(".resultArea").show();
    renderResult(resultList);

  });




  $(".resultArea").on('click', '.viewchart', function () {
    $(".resultPage2").show();
    $(".resultPage1").hide();
    $(".resultPage3").hide();
    renderChartResult();
  });

  $(".resultArea").on('click', '.backBtn', function () {
    $(".resultPage1").show();
    $(".resultPage2").hide();
    $(".resultPage3").hide();
    renderResult(resultList);
  });

  $(".resultArea").on('click', '.viewanswer', function () {
    $(".resultPage3").show();
    $(".resultPage2").hide();
    $(".resultPage1").hide();
    getAllAnswer(resultList);
  });

  $(".resultArea").on('click', '.replay', function () {
    window.location.reload(true);
  });

};
function startTimer(duration, display) {
    var flag=0 ;
    var timer = duration, hours,minutes, seconds;
    loadTest();
    var inter=setInterval(function () {
        hours = parseInt(timer /3600 , 10);
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        hours = hours< 10 ? "0" + hours : hours;  
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;
        if(minutes >= 60 && minutes<120){
            minutes=minutes-60;
        }

        if(minutes >= 120){
            minutes=minutes-120;
        }
        if(!document.hidden){
        display.textContent = hours + ":" + minutes + ":" + seconds;
    }
    else{
        flag=1 ;
        clearInterval(inter) ; 
    }
        if (--timer < 0) {
            timer = duration;
        }
          if(display.textContent=='00:00:00' ||  flag==1){
        document.getElementById("body").style.display = "none";
        if(flag == 1){
            alert("YOU TEST IS OVER!!") ;
        }
        else{
        alert("YOUR TIME IS UP!! :)")
        document.getElementById("completion-notice").style.display = "block";
    }
        clearInterval(inter) ;

    }
    }, 1000);
}

function go() {
    var fiveMinutes = 180*10,
        display = document.querySelector('#demo');
    startTimer(fiveMinutes, display);

};