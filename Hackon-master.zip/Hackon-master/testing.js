function sendEmail(){
  var user ; 
  firebase.database().ref('users/' + uid +'/subjects/').once('value').then(function(snapshot){
    console.log(helo , snapshot);
    user = snapshot.val().CSE;

    console.log(user.toString());

  });
  sending(user);
}
function sending(user){
    Email.send({
    Host: 'smtp.elasticemail.com',
    Username: 'anumi1999@gmail.com',
    Password: '1382941D501DEB5350FBE52512A66A48AA66',
    To : 'dipitvasdevdv@gmail.com , kunalpalkp123@gmail.com',
    From : 'anumi1999@gmail.com' ,
    Subject : "Assignment Notification",
    Body : "This is to notify the students that an assignment of "+ user+" is uploaded. \n \n You need to submit it by " + date + ".\n \n Please check that out and submit the same. \n\n Regards, \n Muskan Jain",
    }).then(
      message => alert("Students are notified")
    );
}

